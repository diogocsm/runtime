<template>
  <div class="about">
    <h1>My Tiny Url</h1>
  </div>
</template>
